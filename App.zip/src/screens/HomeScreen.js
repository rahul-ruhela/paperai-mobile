import React, { useState, useCallback, useRef } from "react";
import {
    View,
    Text,
    FlatList,
    RefreshControl,
    StyleSheet,
    Pressable,
    Alert,
    Platform,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { Swipeable } from "react-native-gesture-handler";
import { useFocusEffect } from "@react-navigation/native";

import GradientScreen from "../ui/GradientScreen";
import Card from "../ui/Card";
import AiHeader from "../ui/AiHeader";
import AppButton from "../ui/AppButton";
import BottomFade from "../ui/BottomFade";

import { listDocuments, deleteDocument } from "../api/documents";

export default function HomeScreen({ navigation }) {
    const [docs, setDocs] = useState([]);
    const [refreshing, setRefreshing] = useState(false);
    const openRow = useRef(null);

    const load = useCallback(async (opts = { silent: false }) => {
        if (!opts.silent) setRefreshing(true);
        try {
            const data = await listDocuments();
            setDocs(data);
        } finally {
            if (!opts.silent) setRefreshing(false);
        }
    }, []);

    useFocusEffect(
        useCallback(() => {
            load({ silent: true });
        }, [load])
    );

    function handleOpen(doc) {
        if (doc.hasAiResult) {
            navigation.navigate("Analysis", {
                docId: doc.id,
                title: doc.title,
            });
        } else {
            navigation.navigate("Process", {
                docId: doc.id,
                title: doc.title,
            });
        }
    }

    function confirmDelete(doc) {
        Alert.alert(
            "Delete document?",
            `"${doc.title}" will be permanently deleted.`,
            [
                { text: "Cancel", style: "cancel" },
                {
                    text: "Delete",
                    style: "destructive",
                    onPress: async () => {
                        setDocs(d => d.filter(x => x.id !== doc.id));
                        try {
                            await deleteDocument(doc.id);
                        } catch {
                            load({ silent: true });
                        }
                    },
                },
            ]
        );
    }

    function renderRightActions(doc) {
        return (
            <Pressable
                onPress={() => confirmDelete(doc)}
                style={styles.deleteAction}
            >
                <Ionicons name="trash-outline" size={22} color="#fff" />
                <Text style={styles.deleteText}>Delete</Text>
            </Pressable>
        );
    }

    function renderItem({ item }) {
        const status = item.status || (item.hasAiResult ? "PROCESSED" : "PENDING");

        let badgeText = "Pending";
        let badgeType = "pending";
        let actionText = "Run AI Analysis →";

        if (status === "QUEUED") {
            badgeText = "Queued";
            actionText = "Waiting in queue…";
        } else if (status === "PROCESSING") {
            badgeText = "Processing";
            actionText = "Analyzing…";
        } else if (status === "PROCESSED") {
            badgeText = "Processed";
            badgeType = "success";
            actionText = "Open AI Analysis →";
        } else if (status === "FAILED") {
            badgeText = "Failed";
            badgeType = "failed";
            actionText = "Retry analysis →";
        }

        return (
            <Swipeable
                ref={(ref) => (openRow.current = ref)}
                renderRightActions={() => renderRightActions(item)}
                overshootRight={false}
            >
                <Pressable
                    onPress={() => handleOpen(item)}
                    style={({ pressed }) => pressed && { opacity: 0.9 }}
                >
                    <Card style={styles.card}>
                        <View style={styles.row}>
                            <Ionicons
                                name="document-text-outline"
                                size={20}
                                color="#A5B4FC"
                            />
                            <Text style={styles.title} numberOfLines={2}>
                                {item.title}
                            </Text>
                        </View>

                        <View style={styles.metaRow}>
                            <Badge text={badgeText} type={badgeType} />
                            {item.category && (
                                <Text style={styles.category}>
                                    {item.category}
                                </Text>
                            )}
                        </View>

                        <Text style={styles.action}>{actionText}</Text>
                    </Card>
                </Pressable>
            </Swipeable>
        );
    }

    return (
        <GradientScreen>
            <SafeAreaView style={{ flex: 1 }}>
                <View style={styles.container}>
                    <AiHeader
                        title="Documents"
                        subtitle="Swipe left to delete"
                    />

                    <FlatList
                        data={docs}
                        keyExtractor={(item) => item.id}
                        renderItem={renderItem}
                        refreshControl={
                            <RefreshControl
                                refreshing={refreshing}
                                onRefresh={load}
                                tintColor="#A5B4FC"
                            />
                        }
                        contentContainerStyle={{ paddingBottom: 80 }}
                        ListEmptyComponent={
                            <View style={styles.empty}>
                                <Text style={styles.emptyTitle}>
                                    No documents yet
                                </Text>
                                <AppButton
                                    title="Upload document"
                                    onPress={() =>
                                        navigation.navigate("Upload")
                                    }
                                />
                            </View>
                        }
                    />
                </View>
            </SafeAreaView>
            <BottomFade />
        </GradientScreen>
    );
}

function Badge({ text, type }) {
    return (
        <View
            style={[
                styles.badge,
                type === "success"
                    ? styles.badgeSuccess
                    : type === "failed"
                        ? styles.badgeFailed
                        : styles.badgePending,
            ]}
        >
            <Text style={styles.badgeText}>{text}</Text>
        </View>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, padding: 18 },

    card: {
        backgroundColor: "rgba(255,255,255,0.08)",
        borderColor: "rgba(255,255,255,0.15)",
        borderRadius: 22,
        ...(Platform.OS === "ios"
            ? {
                shadowColor: "#000",
                shadowOpacity: 0.08,
                shadowRadius: 10,
                shadowOffset: { height: 4 },
            }
            : {}),
    },

    row: {
        flexDirection: "row",
        gap: 10,
        alignItems: "center",
    },

    title: {
        flex: 1,
        fontSize: 15,
        fontWeight: "900",
        color: "#020c45",
    },

    metaRow: {
        marginTop: 10,
        flexDirection: "row",
        gap: 10,
        alignItems: "center",
    },

    category: {
        color: "rgba(255,255,255,0.65)",
        fontWeight: "600",
    },

    badge: {
        paddingHorizontal: 10,
        paddingVertical: 4,
        borderRadius: 999,
    },

    badgeSuccess: {
        backgroundColor: "rgba(34,197,94,0.3)",
    },

    badgePending: {
        backgroundColor: "rgba(251,191,36,0.3)",
    },

    badgeFailed: {
        backgroundColor: "rgba(239,68,68,0.3)",
    },

    badgeText: {
        color: "#020c45",
        fontWeight: "800",
        fontSize: 12,
    },

    action: {
        marginTop: 14,
        fontWeight: "800",
        color: "#004aad",
    },

    deleteAction: {
        backgroundColor: "#EF4444",
        justifyContent: "center",
        alignItems: "center",
        width: 88,
        marginVertical: 6,
        borderRadius: 18,
    },

    deleteText: {
        color: "#fff",
        fontWeight: "900",
        fontSize: 12,
        marginTop: 4,
    },

    empty: {
        marginTop: 60,
        alignItems: "center",
    },

    emptyTitle: {
        color: "#fff",
        fontWeight: "900",
        fontSize: 20,
        marginBottom: 14,
    },
});
